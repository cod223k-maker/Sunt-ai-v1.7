package com.suntai.app;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Locale;

/**
 * Validates URLs the AI agent may open. Web pages can contain prompt-injection text, so the agent must never be
 * able to reach the phone's local network (router, NAS, localhost services) through fetch_url.
 */
final class UrlGuard {
    private UrlGuard() {}

    static URL check(String raw) throws Exception {
        if (raw == null) throw new Exception("URL \u0996\u09BE\u09B2\u09BF");
        String u = raw.trim();
        if (u.length() > 2000) throw new Exception("URL \u0996\u09C1\u09AC \u09AC\u09DC");
        URL url;
        try { url = new URL(u); } catch (MalformedURLException e) { throw new Exception("URL \u09AD\u09C1\u09B2"); }
        return check(url);
    }

    static URL check(URL url) throws Exception {
        String p = url.getProtocol();
        if (!"http".equals(p) && !"https".equals(p)) throw new Exception("\u09B6\u09C1\u09A7\u09C1 http/https URL \u0985\u09A8\u09C1\u09AE\u09CB\u09A6\u09BF\u09A4");
        if (url.getUserInfo() != null) throw new Exception("URL-\u098F user:pass \u0985\u09A8\u09C1\u09AE\u09CB\u09A6\u09BF\u09A4 \u09A8\u09DF");
        String host = url.getHost();
        if (host == null || host.isEmpty()) throw new Exception("URL-\u098F host \u09A8\u09C7\u0987");
        int port = url.getPort();
        if (port != -1 && port != 80 && port != 443) throw new Exception("\u09B6\u09C1\u09A7\u09C1 port 80/443 \u0985\u09A8\u09C1\u09AE\u09CB\u09A6\u09BF\u09A4");
        String h = host.toLowerCase(Locale.ROOT);
        if (h.startsWith("[") && h.endsWith("]")) h = h.substring(1, h.length() - 1);
        if (h.endsWith(".")) h = h.substring(0, h.length() - 1);
        boolean internalName = h.equals("localhost") || h.endsWith(".localhost") || h.endsWith(".local")
                || h.endsWith(".internal") || h.endsWith(".lan") || h.endsWith(".home") || h.endsWith(".corp")
                || (!h.contains(".") && !h.contains(":"));
        if (internalName) throw new Exception("private/internal host \u0985\u09A8\u09C1\u09AE\u09CB\u09A6\u09BF\u09A4 \u09A8\u09DF");
        InetAddress[] addrs;
        try { addrs = InetAddress.getAllByName(h); } catch (Exception e) { throw new Exception("host \u0996\u09C1\u0981\u099C\u09C7 \u09AA\u09BE\u0993\u09DF\u09BE \u09AF\u09BE\u09DF\u09A8\u09BF: " + host); }
        for (InetAddress a : addrs) {
            if (isPrivate(a)) throw new Exception("private/internal \u09A8\u09C7\u099F\u0993\u09DF\u09BE\u09B0\u09CD\u0995 \u0985\u09A8\u09C1\u09AE\u09CB\u09A6\u09BF\u09A4 \u09A8\u09DF");
        }
        return url;
    }

    static boolean isPrivate(InetAddress a) {
        if (a.isAnyLocalAddress() || a.isLoopbackAddress() || a.isLinkLocalAddress() || a.isSiteLocalAddress() || a.isMulticastAddress()) return true;
        byte[] b = a.getAddress();
        if (b.length == 4) {
            int b0 = b[0] & 255, b1 = b[1] & 255;
            if (b0 == 0 || b0 >= 240) return true;
            if (b0 == 100 && b1 >= 64 && b1 <= 127) return true;   // carrier-grade NAT
            if (b0 == 198 && (b1 == 18 || b1 == 19)) return true;  // benchmarking range
        } else if (b.length == 16) {
            if ((b[0] & 0xFE) == 0xFC) return true;                 // fc00::/7 unique local
        }
        return false;
    }
}
