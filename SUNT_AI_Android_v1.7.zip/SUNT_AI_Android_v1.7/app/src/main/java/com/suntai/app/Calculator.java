package com.suntai.app;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Locale;

/** Safe arithmetic evaluator (no scripting engine). Supports + - * / % ^, parentheses and common functions. */
final class Calculator {
    private final String s;
    private int pos = 0;
    private int depth = 0;

    private Calculator(String s) { this.s = s; }

    static String eval(String expr) throws Exception {
        if (expr == null || expr.trim().isEmpty()) throw new Exception("expression \u0996\u09BE\u09B2\u09BF");
        String e = normalize(expr);
        if (e.length() > 200) throw new Exception("expression \u0996\u09C1\u09AC \u09AC\u09DC (\u09B8\u09B0\u09CD\u09AC\u09CB\u099A\u09CD\u099A 200 \u0985\u0995\u09CD\u09B7\u09B0)");
        Calculator c = new Calculator(e);
        double v = c.parseExpr();
        c.skip();
        if (c.pos < c.s.length()) throw new Exception("\u09AC\u09C1\u099D\u09A4\u09C7 \u09AA\u09BE\u09B0\u09BF\u09A8\u09BF: '" + c.s.substring(c.pos) + "'");
        return format(v);
    }

    /** Bengali digits -> ASCII, x/÷/− symbols -> operators, thousands separators removed. */
    static String normalize(String x) {
        StringBuilder b = new StringBuilder();
        for (char ch : x.toCharArray()) {
            if (ch >= '\u09E6' && ch <= '\u09EF') b.append((char) ('0' + (ch - '\u09E6')));
            else if (ch == '\u00D7') b.append('*');
            else if (ch == '\u00F7') b.append('/');
            else if (ch == '\u2212') b.append('-');
            else if (ch == ',') continue;
            else b.append(ch);
        }
        return b.toString().replace("**", "^").trim().toLowerCase(Locale.ROOT);
    }

    private void skip() { while (pos < s.length() && Character.isWhitespace(s.charAt(pos))) pos++; }

    private boolean eat(char c) {
        skip();
        if (pos < s.length() && s.charAt(pos) == c) { pos++; return true; }
        return false;
    }

    private static boolean isD(char c) { return c >= '0' && c <= '9'; }

    private double parseExpr() throws Exception {
        double v = parseTerm();
        while (true) {
            if (eat('+')) v += parseTerm();
            else if (eat('-')) v -= parseTerm();
            else return v;
        }
    }

    private double parseTerm() throws Exception {
        double v = parseUnary();
        while (true) {
            if (eat('*')) v *= parseUnary();
            else if (eat('/')) {
                double d = parseUnary();
                if (d == 0) throw new Exception("\u09B6\u09C2\u09A8\u09CD\u09AF \u09A6\u09BF\u09DF\u09C7 \u09AD\u09BE\u0997 \u0995\u09B0\u09BE \u09AF\u09BE\u09DF \u09A8\u09BE");
                v /= d;
            } else if (eat('%')) {
                double d = parseUnary();
                if (d == 0) throw new Exception("\u09B6\u09C2\u09A8\u09CD\u09AF \u09A6\u09BF\u09DF\u09C7 modulo \u0995\u09B0\u09BE \u09AF\u09BE\u09DF \u09A8\u09BE");
                v %= d;
            } else return v;
        }
    }

    private double parseUnary() throws Exception {
        if (eat('-')) return -parseUnary();
        if (eat('+')) return parseUnary();
        return parsePower();
    }

    private double parsePower() throws Exception {
        double base = parseAtom();
        if (eat('^')) return Math.pow(base, parseUnary());
        return base;
    }

    private double parseAtom() throws Exception {
        skip();
        if (pos >= s.length()) throw new Exception("expression \u0985\u09B8\u09AE\u09CD\u09AA\u09C2\u09B0\u09CD\u09A3");
        if (++depth > 60) throw new Exception("expression \u0996\u09C1\u09AC \u099C\u099F\u09BF\u09B2");
        try {
            char c = s.charAt(pos);
            if (c == '(') {
                pos++;
                double v = parseExpr();
                if (!eat(')')) throw new Exception("')' \u09A8\u09C7\u0987");
                return v;
            }
            if (isD(c) || c == '.') return parseNumber();
            if (c >= 'a' && c <= 'z') {
                int st = pos;
                while (pos < s.length() && s.charAt(pos) >= 'a' && s.charAt(pos) <= 'z') pos++;
                String id = s.substring(st, pos);
                if (id.equals("pi")) return Math.PI;
                if (id.equals("e")) return Math.E;
                if (!eat('(')) throw new Exception("\u0985\u099C\u09BE\u09A8\u09BE \u09B6\u09AC\u09CD\u09A6: " + id);
                double a = parseExpr();
                if (!eat(')')) throw new Exception("')' \u09A8\u09C7\u0987");
                return fn(id, a);
            }
            throw new Exception("\u0985\u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 \u099A\u09BF\u09B9\u09CD\u09A8: '" + c + "'");
        } finally {
            depth--;
        }
    }

    private double parseNumber() throws Exception {
        int st = pos;
        while (pos < s.length() && (isD(s.charAt(pos)) || s.charAt(pos) == '.')) pos++;
        if (pos < s.length() && s.charAt(pos) == 'e') {
            int p = pos + 1;
            if (p < s.length() && (s.charAt(p) == '+' || s.charAt(p) == '-')) p++;
            if (p < s.length() && isD(s.charAt(p))) {
                while (p < s.length() && isD(s.charAt(p))) p++;
                pos = p;
            }
        }
        String num = s.substring(st, pos);
        try {
            return Double.parseDouble(num);
        } catch (NumberFormatException ex) {
            throw new Exception("\u09AD\u09C1\u09B2 \u09B8\u0982\u0996\u09CD\u09AF\u09BE: " + num);
        }
    }

    private static double fn(String id, double a) throws Exception {
        switch (id) {
            case "sqrt": if (a < 0) throw new Exception("\u098B\u09A3\u09BE\u09A4\u09CD\u09AE\u0995 \u09B8\u0982\u0996\u09CD\u09AF\u09BE\u09B0 sqrt \u09A8\u09BE\u0987"); return Math.sqrt(a);
            case "abs": return Math.abs(a);
            case "sin": return Math.sin(a);
            case "cos": return Math.cos(a);
            case "tan": return Math.tan(a);
            case "ln": if (a <= 0) throw new Exception("ln \u0995\u09C7\u09AC\u09B2 \u09A7\u09A8\u09BE\u09A4\u09CD\u09AE\u0995 \u09B8\u0982\u0996\u09CD\u09AF\u09BE\u09DF"); return Math.log(a);
            case "log": case "log10": if (a <= 0) throw new Exception("log \u0995\u09C7\u09AC\u09B2 \u09A7\u09A8\u09BE\u09A4\u09CD\u09AE\u0995 \u09B8\u0982\u0996\u09CD\u09AF\u09BE\u09DF"); return Math.log10(a);
            case "exp": return Math.exp(a);
            case "floor": return Math.floor(a);
            case "ceil": return Math.ceil(a);
            case "round": return Math.rint(a);
            default: throw new Exception("\u0985\u099C\u09BE\u09A8\u09BE function: " + id);
        }
    }

    private static String format(double v) throws Exception {
        if (Double.isNaN(v) || Double.isInfinite(v)) throw new Exception("\u09AB\u09B2\u09BE\u09AB\u09B2 \u09B8\u0982\u099C\u09CD\u099E\u09BE\u09DF\u09BF\u09A4 \u09A8\u09DF/\u0985\u09B8\u09C0\u09AE");
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return Long.toString((long) v);
        BigDecimal bd = new BigDecimal(v).round(new MathContext(12)).stripTrailingZeros();
        double a = Math.abs(v);
        return (a >= 1e-6 && a < 1e15) ? bd.toPlainString() : bd.toString();
    }
}
