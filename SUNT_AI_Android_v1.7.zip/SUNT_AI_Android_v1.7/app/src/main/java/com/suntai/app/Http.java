package com.suntai.app;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Small HTTP helper: JSON POST with retry/backoff, guarded GET for the agent. */
final class Http {
    private Http() {}

    static final class HttpError extends Exception {
        final int code;
        HttpError(int code, String msg) { super(msg); this.code = code; }
    }

    static final class Page {
        String type = "";
        String text = "";
    }

    static String postJson(String url, String bearer, JSONObject body, int connectMs, int readMs, int retries) throws Exception {
        byte[] payload = body.toString().getBytes("UTF-8");
        int attempt = 0;
        while (true) {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            try {
                c.setRequestMethod("POST");
                c.setConnectTimeout(connectMs);
                c.setReadTimeout(readMs);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("Accept", "application/json");
                if (bearer != null && !bearer.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + bearer);
                OutputStream out = c.getOutputStream();
                out.write(payload);
                out.close();
                int code = c.getResponseCode();
                String text = readStream(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), 2000000, "UTF-8");
                if (code >= 200 && code < 300) return text;
                boolean retryable = code == 429 || code == 500 || code == 502 || code == 503 || code == 504;
                if (retryable && attempt < retries) {
                    long wait = retryAfterMs(c.getHeaderField("Retry-After"), 1500L * (attempt + 1));
                    attempt++;
                    Thread.sleep(wait);
                    continue;
                }
                throw new HttpError(code, friendly(code, text, bearer));
            } finally {
                c.disconnect();
            }
        }
    }

    static long retryAfterMs(String header, long def) {
        if (header == null) return def;
        try {
            long s = Long.parseLong(header.trim());
            return Math.max(500L, Math.min(10000L, s * 1000L));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static String friendly(int code, String body, String secret) {
        String detail = body == null ? "" : body.trim();
        try {
            JSONObject j = new JSONObject(detail);
            Object err = j.opt("error");
            if (err instanceof JSONObject) {
                String m = ((JSONObject) err).optString("message", "");
                if (!m.isEmpty()) detail = m;
            } else if (err instanceof String) {
                detail = (String) err;
            } else if (j.has("message")) {
                detail = j.optString("message", detail);
            }
        } catch (Exception ignored) { }
        if (secret != null && secret.length() >= 6) detail = detail.replace(secret, "***");
        detail = TextUtil.clip(detail, 300);
        String hint;
        switch (code) {
            case 400: hint = "\u0985\u09A8\u09C1\u09B0\u09CB\u09A7 \u09A0\u09BF\u0995 \u09A8\u09DF (model ID/format \u09AA\u09B0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09B0\u09CB)"; break;
            case 401: case 403: hint = "API key \u09AD\u09C1\u09B2 \u09AC\u09BE \u0985\u09A8\u09C1\u09AE\u09A4\u09BF \u09A8\u09C7\u0987"; break;
            case 404: hint = "URL \u09AC\u09BE model ID \u09A0\u09BF\u0995 \u09A8\u09DF"; break;
            case 429: hint = "rate limit/quota \u09B6\u09C7\u09B7 \u2014 \u098F\u0995\u099F\u09C1 \u09AA\u09B0\u09C7 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09CB"; break;
            default: hint = code >= 500 ? "provider server \u09B8\u09AE\u09B8\u09CD\u09AF\u09BE" : "";
        }
        return "HTTP " + code + (hint.isEmpty() ? "" : " \u2022 " + hint) + (detail.isEmpty() ? "" : "\n" + detail);
    }

    /** GET for the agent: every hop (including redirects) is checked by UrlGuard. */
    static Page get(String rawUrl, int maxBytes, int timeoutMs, String accept) throws Exception {
        String current = rawUrl;
        for (int hop = 0; hop < 4; hop++) {
            URL url = UrlGuard.check(current);
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            try {
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(timeoutMs);
                c.setReadTimeout(timeoutMs);
                c.setRequestProperty("User-Agent", "SUNT-AI/1.7 (Android; ST-2 agent)");
                c.setRequestProperty("Accept", accept);
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null) throw new Exception("redirect \u0995\u09BF\u09A8\u09CD\u09A4\u09C1 Location \u09A8\u09C7\u0987");
                    current = new URL(url, loc).toString();
                    continue;
                }
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
                String ct = c.getContentType();
                String lower = ct == null ? "" : ct.toLowerCase(java.util.Locale.ROOT);
                if (!lower.isEmpty() && !(lower.startsWith("text/") || lower.contains("json") || lower.contains("xml")))
                    throw new Exception("\u09B6\u09C1\u09A7\u09C1 text/HTML/JSON \u09AA\u09C7\u099C \u09AA\u09DC\u09BE \u09AF\u09BE\u09DF (type: " + ct + ")");
                Page p = new Page();
                p.type = lower;
                p.text = readStream(c.getInputStream(), maxBytes, charsetOf(ct));
                return p;
            } finally {
                c.disconnect();
            }
        }
        throw new Exception("\u0985\u09A8\u09C7\u0995 \u09AC\u09C7\u09B6\u09BF redirect");
    }

    static String charsetOf(String contentType) {
        if (contentType != null) {
            int i = contentType.toLowerCase(java.util.Locale.ROOT).indexOf("charset=");
            if (i >= 0) {
                String cs = contentType.substring(i + 8).trim();
                int end = cs.indexOf(';');
                if (end >= 0) cs = cs.substring(0, end);
                cs = cs.replace("\"", "").trim();
                if (java.nio.charset.Charset.isSupported(cs)) return cs;
            }
        }
        return "UTF-8";
    }

    static String readStream(InputStream in, int max, String charset) throws Exception {
        if (in == null) return "";
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while (bos.size() < max && (n = in.read(buf)) != -1) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), charset);
        } finally {
            in.close();
        }
    }
}
