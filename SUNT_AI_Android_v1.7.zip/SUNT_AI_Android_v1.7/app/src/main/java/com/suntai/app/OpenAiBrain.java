package com.suntai.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/** Brain backed by any OpenAI-compatible /chat/completions endpoint (online provider or own local server). */
final class OpenAiBrain implements Brain {
    private final String endpoint, model, key;

    OpenAiBrain(String base, String model, String key, String missingMessage) throws Exception {
        String b = base == null ? "" : base.trim();
        if (b.isEmpty() || model == null || model.trim().isEmpty()) throw new Exception(missingMessage);
        this.endpoint = endpointFor(b, "chat/completions");
        this.model = model.trim();
        this.key = key == null ? "" : key.trim();
    }

    static String endpointFor(String base, String path) throws Exception {
        String b = base.trim();
        if (!b.startsWith("http://") && !b.startsWith("https://"))
            throw new Exception("URL \u0985\u09AC\u09B6\u09CD\u09AF\u0987 http:// \u09AC\u09BE https:// \u09A6\u09BF\u09DF\u09C7 \u09B6\u09C1\u09B0\u09C1 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7\u0964");
        while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
        if (b.endsWith("/" + path)) return b;
        return b + "/" + path;
    }

    @Override public String chat(List<String[]> messages, double temperature) throws Exception {
        String resp;
        try {
            resp = Http.postJson(endpoint, key, body(messages, temperature, true), 12000, 120000, 2);
        } catch (Http.HttpError e) {
            // Some models (e.g. reasoning models) reject a custom temperature: retry once without it.
            if (e.code == 400 && String.valueOf(e.getMessage()).toLowerCase(java.util.Locale.ROOT).contains("temperature"))
                resp = Http.postJson(endpoint, key, body(messages, temperature, false), 12000, 120000, 2);
            else throw e;
        }
        JSONObject j = new JSONObject(resp);
        JSONArray choices = j.optJSONArray("choices");
        if (choices == null || choices.length() == 0) throw new Exception("Model-\u098F\u09B0 response \u09AC\u09C1\u099D\u09A4\u09C7 \u09AA\u09BE\u09B0\u09BF\u09A8\u09BF\u0964");
        JSONObject msg = choices.getJSONObject(0).optJSONObject("message");
        String content = (msg == null || msg.isNull("content")) ? "" : msg.optString("content", "");
        content = content.replaceAll("(?s)<think>.*?</think>", "").trim();
        if (content.isEmpty()) throw new Exception("Model \u0996\u09BE\u09B2\u09BF \u0989\u09A4\u09CD\u09A4\u09B0 \u09AA\u09BE\u09A0\u09BF\u09DF\u09C7\u099B\u09C7\u0964");
        return content;
    }

    private JSONObject body(List<String[]> messages, double temperature, boolean withTemp) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", model);
        JSONArray arr = new JSONArray();
        for (String[] m : messages) {
            JSONObject o = new JSONObject();
            o.put("role", m[0]);
            o.put("content", m[1]);
            arr.put(o);
        }
        body.put("messages", arr);
        if (withTemp) body.put("temperature", temperature);
        return body;
    }
}
