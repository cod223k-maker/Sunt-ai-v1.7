package com.suntai.app;

import java.util.List;

/** A chat-completion backend. messages: {role, content} pairs, system message first. */
interface Brain {
    String chat(List<String[]> messages, double temperature) throws Exception;
}
