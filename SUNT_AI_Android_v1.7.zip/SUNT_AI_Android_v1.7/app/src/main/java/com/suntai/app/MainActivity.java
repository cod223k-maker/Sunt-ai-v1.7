package com.suntai.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Gravity;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private Kv kv;
    private String draft = "";
    private LinearLayout root, chatList;
    private EditText messageBox;
    private TextView status;
    private static final int PICK_FILE = 41, PICK_VIDEO = 42;
    private String selectedFileText = "";
    private Uri selectedVideoUri = null;
    private String selectedFileName = "";
    private String videoTask = "";
    private ScrollView chatScroll;
    private boolean onChat = false, busy = false;
    private int chatEpoch = 0;
    private final java.util.ArrayList<String[]> bubbles = new java.util.ArrayList<>();
    private final java.util.ArrayList<String[]> history = new java.util.ArrayList<>();

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private String apiUrl(String base, String path) throws Exception {
        String b = base.trim();
        if (!b.startsWith("http://") && !b.startsWith("https://")) throw new Exception("URL অবশ্যই http:// বা https:// দিয়ে শুরু হতে হবে।");
        while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
        if (b.endsWith("/" + path)) return b;
        return b + "/" + path;
    }

        @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("sunt_settings", MODE_PRIVATE);
        kv = MemoryStore.kv(prefs);
        loadChat();
        showChat();
    }

    @Override public void onBackPressed() {
        if (!onChat) showChat();
        else super.onBackPressed();
    }

    // ---------- chat persistence (survives app restart) ----------
    private void saveChat() {
        try {
            JSONArray b = new JSONArray();
            for (int i = Math.max(0, bubbles.size() - 60); i < bubbles.size(); i++) {
                JSONObject o = new JSONObject();
                o.put("w", bubbles.get(i)[0]);
                o.put("t", TextUtil.clip(bubbles.get(i)[1], 20000));
                b.put(o);
            }
            JSONArray h = new JSONArray();
            for (int i = Math.max(0, history.size() - 40); i < history.size(); i++) {
                JSONObject o = new JSONObject();
                o.put("r", history.get(i)[0]);
                o.put("c", TextUtil.clip(history.get(i)[1], 6000));
                h.put(o);
            }
            prefs.edit().putString("chat_bubbles_v1", b.toString()).putString("chat_history_v1", h.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void loadChat() {
        try {
            JSONArray b = new JSONArray(prefs.getString("chat_bubbles_v1", "[]"));
            for (int i = 0; i < b.length(); i++) {
                JSONObject o = b.getJSONObject(i);
                bubbles.add(new String[]{o.optString("w"), o.optString("t")});
            }
            JSONArray h = new JSONArray(prefs.getString("chat_history_v1", "[]"));
            for (int i = 0; i < h.length(); i++) {
                JSONObject o = h.getJSONObject(i);
                history.add(new String[]{o.optString("r"), o.optString("c")});
            }
            while (!history.isEmpty() && !"user".equals(history.get(0)[0])) history.remove(0);
        } catch (Exception ignored) {
            bubbles.clear();
            history.clear();
        }
    }

    private void shell(String subtitle) {
        if (onChat && messageBox != null) draft = messageBox.getText().toString();
        onChat = false;
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(10));
        root.setBackgroundColor(0xFFF3F6FB);
        TextView title = new TextView(this);
        title.setText("SUNT AI");
        title.setTextSize(28);
        title.setTextColor(0xFF142B55);
        title.setTypeface(null, 1);
        root.addView(title);
        TextView sub = new TextView(this);
        sub.setText(subtitle);
        sub.setTextSize(12);
        sub.setTextColor(0xFF64748B);
        root.addView(sub);
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tab(tabs, "চ্যাট", this::showChat);
        tab(tabs, "Brain", this::showBrainSettings);
        tab(tabs, "Memory", this::showMemory);
        tab(tabs, "ছবি", this::showImage);
        tab(tabs, "ফাইল", this::pickFile);
        tab(tabs, "ভিডিও", this::showVideo);
        tab(tabs, "Skills", this::showSkills);
        hsv.addView(tabs);
        root.addView(hsv);
    }

    private void tab(LinearLayout row, String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        row.addView(b);
        b.setOnClickListener(v -> action.run());
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setPadding(0, 10, 0, 6);
        t.setTextSize(13);
        t.setTextColor(0xFF263449);
        return t;
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        return e;
    }

    private void showChat() {
        shell("Version 1.7 • ST-1 Brain + ST-2 Agent");
        chatScroll = new ScrollView(this);
        chatList = new LinearLayout(this);
        chatList.setOrientation(LinearLayout.VERTICAL);
        chatScroll.addView(chatList);
        root.addView(chatScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout composer = new LinearLayout(this);
        messageBox = new EditText(this);
        messageBox.setHint("কোড, অ্যাপ, ওয়েবসাইট বা প্রশ্ন লিখো...");
        messageBox.setMaxLines(5);
        messageBox.setText(draft);
        composer.addView(messageBox, new LinearLayout.LayoutParams(0, -2, 1));
        Button send = new Button(this);
        send.setText("পাঠাও");
        send.setOnClickListener(v -> sendChat());
        composer.addView(send);
        Button clear = new Button(this);
        clear.setText("নতুন");
        clear.setOnClickListener(v -> {
            chatEpoch++; busy = false;
            bubbles.clear(); history.clear();
            selectedFileText = ""; selectedFileName = ""; draft = "";
            saveChat();
            showChat();
        });
        composer.addView(clear);
        root.addView(composer);
        status = new TextView(this);
        status.setText(selectedFileName.isEmpty() ? "Brain ট্যাবে model যুক্ত করলে পূর্ণ ST-1 চালু হবে।" : "ফাইল যুক্ত আছে: " + selectedFileName);
        root.addView(status);
        setContentView(root);
        if (bubbles.isEmpty())
            bubbles.add(new String[]{"SUNT", "স্বাগতম! আমি SUNT AI (ST-1 Brain)। পূর্ণ শক্তির জন্য Brain ট্যাবে একটি model যুক্ত করে \"পরীক্ষা করো\" চাপো। model ছাড়া আমি শুধু Lite mode-এ (হিসাব, সময়, মেমোরি) কাজ করি।"});
        for (String[] b : bubbles) addBubbleView(b[0], b[1]);
        onChat = true;
        scrollDown();
    }

    private void scrollDown() {
        if (chatScroll != null) chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void addBubble(String who, String text) {
        bubbles.add(new String[]{who, text});
        if (onChat && chatList != null) { addBubbleView(who, text); scrollDown(); }
    }

    private void addBubbleView(String who, String text) {
        TextView t = new TextView(this);
        t.setText(who + "\n" + text);
        t.setTextSize(14);
        t.setTextColor(0xFF172033);
        t.setTextIsSelectable(true);
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        t.setBackgroundColor(who.equals("তুমি") ? 0xFFDCEAFE : 0xFFFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(5), 0, dp(5));
        chatList.addView(t, lp);
    }

        private void sendChat() {
        if (busy) return;
        final String prompt = messageBox.getText().toString().trim();
        if (prompt.isEmpty()) return;
        final String fileCtx = selectedFileText;
        final String content = fileCtx.isEmpty() ? prompt : prompt + "\n\nUser file text:\n" + fileCtx;
        addBubble("তুমি", fileCtx.isEmpty() ? prompt : prompt + "\n[ফাইল: " + selectedFileName + "]");
        messageBox.setText("");
        draft = "";
        selectedFileText = ""; selectedFileName = "";
        history.add(new String[]{"user", content});
        final List<String[]> snapshot = new ArrayList<>(history);
        final String mode = prefs.getString("brain_mode", "auto");
        final ST1Brain.Options opt = ST1Brain.Options.load(prefs);
        final String explicit = opt.useMemory ? MemoryStore.extractExplicit(prompt) : null;
        final int epoch = chatEpoch;
        busy = true;
        status.setText("ST-1 ভাবছে...");
        new Thread(() -> {
            String note = "";
            if (explicit != null) {
                try {
                    MemoryStore.add(kv, explicit, "user");
                    note = "\n\n💾 মনে রাখলাম: " + explicit;
                } catch (Exception me) {
                    note = "\n\n⚠️ মনে রাখা যায়নি: " + me.getMessage();
                }
            }
            final String memNote = note;
            try {
                final Reply r = think(mode, snapshot, opt, prompt, fileCtx, s -> runOnUiThread(() -> {
                    if (epoch == chatEpoch && onChat && busy) status.setText(s);
                }));
                if (r.real && opt.useMemory) MemoryStore.addEpisode(kv, prompt, r.answer);
                runOnUiThread(() -> {
                    if (epoch != chatEpoch) return;
                    busy = false;
                    if (r.real) history.add(new String[]{"assistant", r.answer});
                    else if (!history.isEmpty()) history.remove(history.size() - 1);
                    addBubble("SUNT • " + r.source, r.answer + memNote);
                    saveChat();
                    if (onChat) status.setText("উত্তর এসেছে: " + r.source);
                });
            } catch (Exception e) {
                String err0 = e.getMessage() == null ? "Connection error" : e.getMessage();
                final String err = err0.length() > 600 ? err0.substring(0, 600) + "..." : err0;
                runOnUiThread(() -> {
                    if (epoch != chatEpoch) return;
                    busy = false;
                    if (!history.isEmpty()) history.remove(history.size() - 1);
                    addBubble("SUNT • সমস্যা", err + memNote);
                    saveChat();
                    if (onChat) status.setText("সমস্যা হয়েছে");
                });
            }
        }).start();
    }

    private static final class Reply {
        String answer = "", source = "";
        boolean real = true;
    }

    private boolean localConfigured() {
        return !prefs.getString("local_url", "").trim().isEmpty() && !prefs.getString("local_model", "").trim().isEmpty();
    }

    /** Dual Brain: Online first, then own Local endpoint, then the offline Lite helper (auto mode). */
    private Reply think(String mode, List<String[]> turns, ST1Brain.Options opt, String prompt, String fileCtx, ST2Agent.Listener ls) throws Exception {
        String firstError = null;
        if (!"local".equals(mode)) {
            try {
                return runBrain(false, turns, opt, ls);
            } catch (Exception e) {
                if ("online".equals(mode)) throw e;
                firstError = e.getMessage();
            }
        }
        if ("local".equals(mode) || localConfigured()) {
            try {
                Reply r = runBrain(true, turns, opt, ls);
                if (firstError != null) r.source += " (Online ব্যর্থ)";
                return r;
            } catch (Exception e) {
                if ("local".equals(mode)) throw e;
                if (firstError == null) firstError = e.getMessage();
            }
        }
        Reply r = new Reply();
        r.answer = LiteBrain.reply(prompt, fileCtx, firstError);
        r.source = "ST-1 Lite (offline)";
        r.real = false;
        return r;
    }

    private Reply runBrain(boolean local, List<String[]> turns, ST1Brain.Options opt, ST2Agent.Listener ls) throws Exception {
        Brain brain = makeBrain(local, null, null, null);
        ST2Agent.Result res = new ST2Agent(kv, opt, brain, ls).run(turns);
        Reply r = new Reply();
        r.answer = res.answer;
        StringBuilder src = new StringBuilder(local ? "Local Brain" : "Online Brain");
        src.append(" • ").append(opt.effort.key);
        if (!res.tools.isEmpty()) src.append(" • 🔧 ").append(joinUnique(res.tools));
        if (res.revised) src.append(" • ✅ সংশোধিত");
        else if (res.checked) src.append(" • ✅ যাচাইকৃত");
        r.source = src.toString();
        return r;
    }

    private static String joinUnique(List<String> l) {
        java.util.LinkedHashSet<String> s = new java.util.LinkedHashSet<>(l);
        StringBuilder b = new StringBuilder();
        for (String x : s) { if (b.length() > 0) b.append(", "); b.append(x); }
        return b.toString();
    }

    /** Builds a brain from saved settings, or from explicit values (used by the connection test). */
    private Brain makeBrain(boolean local, String base, String model, String key) throws Exception {
        if (base == null) base = prefs.getString(local ? "local_url" : "base_url", "");
        if (model == null) model = prefs.getString(local ? "local_model" : "chat_model", "");
        if (key == null) key = prefs.getString(local ? "local_key" : "api_key", "");
        return new OpenAiBrain(base, model, key, local ? "Local endpoint/model সেট করা নেই।" : "Online API URL/model সেট করা নেই।");
    }

    private void testBrain(boolean local, String base, String model, String key) {
        final long t0 = System.currentTimeMillis();
        Toast.makeText(this, "পরীক্ষা চলছে...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String msg;
            try {
                Brain b = makeBrain(local, base, model, key);
                List<String[]> m = new ArrayList<>();
                m.add(new String[]{"user", "Reply with exactly one word: OK"});
                String out = b.chat(m, 0.0);
                msg = "✅ সংযোগ ঠিক আছে (" + (System.currentTimeMillis() - t0) + " ms)\nModel-এর উত্তর: " + TextUtil.clip(out, 120)
                        + "\n\nএখন \"সব Brain সেটিংস সেভ করো\" চাপো।";
            } catch (Exception e) {
                msg = "❌ সংযোগ হয়নি:\n" + (e.getMessage() == null ? e.toString() : TextUtil.clip(e.getMessage(), 500));
            }
            final String shown = msg;
            runOnUiThread(() -> new AlertDialog.Builder(this).setTitle(local ? "Local Brain পরীক্ষা" : "Online Brain পরীক্ষা")
                    .setMessage(shown).setPositiveButton("ঠিক আছে", null).show());
        }).start();
    }

    

    

        private void showBrainSettings() {
        shell("Brain configuration • ST-1 / ST-2");
        final ST1Brain.Options opt = ST1Brain.Options.load(prefs);
        ScrollView sc = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(4, 4, 4, 12);
        box.setOrientation(LinearLayout.VERTICAL);

        box.addView(label("কোন Brain ব্যবহার করবে?"));
        final Spinner mode = new Spinner(this);
        mode.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"Auto: Online → Local → Lite fallback", "শুধু Online Brain", "শুধু Local/নিজস্ব endpoint"}));
        String saved = prefs.getString("brain_mode", "auto");
        mode.setSelection(saved.equals("online") ? 1 : saved.equals("local") ? 2 : 0);
        box.addView(mode);

        box.addView(label("ST-1 চিন্তার মাত্রা (Reasoning effort)"));
        final Spinner effort = new Spinner(this);
        effort.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"Fast — দ্রুত ও সংক্ষিপ্ত", "Balanced — সাধারণ (প্রস্তাবিত)", "Deep — গভীর, ধীর, বেশি token"}));
        effort.setSelection(opt.effort == ST1Brain.Effort.FAST ? 0 : opt.effort == ST1Brain.Effort.DEEP ? 2 : 1);
        box.addView(effort);
        final CheckBox toolsCb = new CheckBox(this);
        toolsCb.setText("ST-2 Tools চালু (হিসাব, সময়, Wikipedia, ওয়েব পেজ পড়া, মেমোরি)");
        toolsCb.setChecked(opt.tools);
        box.addView(toolsCb);
        final CheckBox checkCb = new CheckBox(this);
        checkCb.setText("Self-check: উত্তর দেওয়ার আগে নিজে যাচাই (একটি বাড়তি API call)");
        checkCb.setChecked(opt.selfCheck);
        box.addView(checkCb);
        final CheckBox memCb = new CheckBox(this);
        memCb.setText("Memory ব্যবহার করো (Memory ট্যাবে দেখা/মোছা যায়)");
        memCb.setChecked(opt.useMemory);
        box.addView(memCb);

        box.addView(label("ONLINE BRAIN — provider API"));
        final EditText base = field("API Base URL (যেমন https://.../v1)", prefs.getString("base_url", ""));
        final EditText model = field("Chat model ID (provider-এর docs থেকে নাও)", prefs.getString("chat_model", ""));
        final EditText key = field("API key", prefs.getString("api_key", ""));
        key.setInputType(129);
        final String[] presetNames = {"Preset বেছে URL বসাও (ঐচ্ছিক)", "Google Gemini (OpenAI-compatible)", "Groq", "OpenRouter"};
        final String[] presetUrls = {"", "https://generativelanguage.googleapis.com/v1beta/openai", "https://api.groq.com/openai/v1", "https://openrouter.ai/api/v1"};
        Spinner preset = new Spinner(this);
        preset.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, presetNames));
        preset.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View v, int pos, long id) {
                if (pos > 0) base.setText(presetUrls[pos]);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        box.addView(preset);
        box.addView(base); box.addView(model); box.addView(key);
        Button testOnline = new Button(this);
        testOnline.setText("Online Brain পরীক্ষা করো");
        testOnline.setOnClickListener(v -> testBrain(false, base.getText().toString().trim(), model.getText().toString().trim(), key.getText().toString().trim()));
        box.addView(testOnline);

        box.addView(label("LOCAL / OWN BRAIN — OpenAI-compatible server"));
        final EditText localUrl = field("Local server URL (LAN/server URL)", prefs.getString("local_url", ""));
        final EditText localModel = field("Local model ID", prefs.getString("local_model", ""));
        final EditText localKey = field("Local key (optional)", prefs.getString("local_key", ""));
        localKey.setInputType(129);
        box.addView(localUrl); box.addView(localModel); box.addView(localKey);
        Button testLocal = new Button(this);
        testLocal.setText("Local Brain পরীক্ষা করো");
        testLocal.setOnClickListener(v -> testBrain(true, localUrl.getText().toString().trim(), localModel.getText().toString().trim(), localKey.getText().toString().trim()));
        box.addView(testLocal);

        box.addView(label("IMAGE — OpenAI-compatible /images/generations"));
        final EditText imgUrl = field("Image API Base URL", prefs.getString("image_url", ""));
        final EditText imgModel = field("Image model ID", prefs.getString("image_model", ""));
        final EditText imgKey = field("Image API key", prefs.getString("image_key", ""));
        imgKey.setInputType(129);
        box.addView(imgUrl); box.addView(imgModel); box.addView(imgKey);

        box.addView(label("নিজের Skill / System instruction (এখানে নিয়ম লিখে Save করো)"));
        final EditText skill = new EditText(this);
        skill.setMinLines(4);
        skill.setGravity(Gravity.TOP);
        skill.setText(prefs.getString("skill_prompt", ""));
        skill.setHint("যেমন: উত্তর বাংলায় দেবে, কোড ধাপে ধাপে ব্যাখ্যা করবে...");
        box.addView(skill);

        Button save = new Button(this);
        save.setText("সব Brain সেটিংস সেভ করো");
        save.setOnClickListener(v -> {
            String m = mode.getSelectedItemPosition() == 1 ? "online" : mode.getSelectedItemPosition() == 2 ? "local" : "auto";
            String e = effort.getSelectedItemPosition() == 0 ? "fast" : effort.getSelectedItemPosition() == 2 ? "deep" : "balanced";
            prefs.edit().putString("brain_mode", m)
                .putString("effort", e)
                .putString("tools_on", toolsCb.isChecked() ? "1" : "0")
                .putString("self_check", checkCb.isChecked() ? "1" : "0")
                .putString("use_memory", memCb.isChecked() ? "1" : "0")
                .putString("base_url", base.getText().toString().trim())
                .putString("chat_model", model.getText().toString().trim())
                .putString("api_key", key.getText().toString().trim())
                .putString("local_url", localUrl.getText().toString().trim())
                .putString("local_model", localModel.getText().toString().trim())
                .putString("local_key", localKey.getText().toString().trim())
                .putString("image_url", imgUrl.getText().toString().trim())
                .putString("image_model", imgModel.getText().toString().trim())
                .putString("image_key", imgKey.getText().toString().trim())
                .putString("skill_prompt", skill.getText().toString().trim()).apply();
            new AlertDialog.Builder(this).setMessage("Brain ও Skill settings সেভ হয়েছে।")
                .setPositiveButton("ঠিক আছে", (d, w) -> showChat()).show();
        });
        box.addView(save);

        TextView warn = label("মনে রাখবে: ST-1/ST-2 নিজে language model নয় — এটি তোমার দেওয়া model-কে ভালোভাবে ভাবতে, মনে রাখতে ও tool চালাতে শেখায়। উত্তরের মান নির্ভর করে model-এর উপর। Free tier-এর limit/model নাম provider বদলাতে পারে, তাই provider-এর docs দেখে নাও। API key ফোনে সাধারণ storage-এ থাকে; অন্য কাউকে key দিও না। http:// URL শুধু নিজের LAN server-এর জন্য ব্যবহার করো।");
        warn.setTextColor(0xFF9A3412);
        box.addView(warn);
        sc.addView(box);
        root.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void showMemory() {
        shell("ST Memory • দীর্ঘমেয়াদি স্মৃতি");
        ScrollView sc = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(4, 4, 4, 12);
        box.addView(label("চ্যাটে লিখতে পারো: \"মনে রাখো: আমি Java Android শিখছি\"। এখানে সব তথ্য দেখা, যোগ ও মোছা যায়। 👤 = তুমি যোগ করেছ, 🤖 = AI যোগ করেছে। পাসওয়ার্ড/API key রাখা হয় না।"));
        final EditText input = field("নতুন তথ্য (যেমন: আমি ঢাকায় থাকি)", "");
        box.addView(input);
        final LinearLayout listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        final TextView count = label("");
        final Runnable[] refresh = new Runnable[1];
        refresh[0] = () -> {
            listBox.removeAllViews();
            List<MemoryStore.Fact> all = MemoryStore.list(kv);
            count.setText(all.isEmpty() ? "এখনো কিছু সেভ করা নেই।" : "মোট " + all.size() + "টি তথ্য:");
            for (int i = all.size() - 1; i >= 0; i--) {
                final MemoryStore.Fact f = all.get(i);
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(dp(8), dp(6), dp(8), dp(6));
                row.setBackgroundColor(0xFFFFFFFF);
                row.setGravity(Gravity.CENTER_VERTICAL);
                TextView t = new TextView(this);
                t.setText(("auto".equals(f.src) ? "🤖 " : "👤 ") + f.text);
                t.setTextColor(0xFF172033);
                t.setTextSize(14);
                row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
                Button del = new Button(this);
                del.setText("মুছো");
                del.setOnClickListener(v -> { MemoryStore.delete(kv, f.id); refresh[0].run(); });
                row.addView(del);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.setMargins(0, dp(4), 0, dp(4));
                listBox.addView(row, lp);
            }
        };
        Button add = new Button(this);
        add.setText("যোগ করো");
        add.setOnClickListener(v -> {
            try {
                MemoryStore.add(kv, input.getText().toString(), "user");
                input.setText("");
                refresh[0].run();
            } catch (Exception e) {
                Toast.makeText(this, e.getMessage() == null ? "যোগ করা যায়নি" : e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        box.addView(add);
        box.addView(count);
        box.addView(listBox);
        Button clear = new Button(this);
        clear.setText("সব স্মৃতি মুছো");
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setMessage("সব সংরক্ষিত তথ্য ও আগের কথোপকথনের সারাংশ মুছে যাবে। নিশ্চিত?")
            .setPositiveButton("হ্যাঁ, মুছো", (d, w) -> { MemoryStore.clearAll(kv); refresh[0].run(); })
            .setNegativeButton("না", null).show());
        box.addView(clear);
        refresh[0].run();
        sc.addView(box);
        root.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void showImage() {
        shell("Image generation • OpenAI-compatible adapter");
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        EditText prompt = new EditText(this);
        prompt.setMinLines(3); prompt.setGravity(Gravity.TOP);
        prompt.setHint("যে ছবি চাও তার বিস্তারিত prompt...");
        box.addView(prompt);
        box.addView(label("এই adapter /images/generations endpoint এবং b64_json/url response format সমর্থন করে। Provider ভেদে কাজ নাও করতে পারে।"));
        Button go = new Button(this);
        go.setText("ছবি তৈরি করো");
        go.setOnClickListener(v -> {
            String p = prompt.getText().toString().trim();
            if (p.isEmpty()) return;
            go.setEnabled(false); go.setText("তৈরি হচ্ছে...");
            new Thread(() -> {
                try {
                    final Bitmap bmp = loadImage(generateImage(p));
                    runOnUiThread(() -> {
                        go.setEnabled(true); go.setText("ছবি তৈরি করো");
                        showBitmap(bmp);
                    });
                } catch (Exception e) {
                    String err = e.getMessage() == null ? "Image API error" : e.getMessage();
                    runOnUiThread(() -> {
                        go.setEnabled(true); go.setText("ছবি তৈরি করো");
                        new AlertDialog.Builder(this).setMessage("ছবি তৈরি হয়নি: " + err + "\nImage provider-এর endpoint/model/key ও API format পরীক্ষা করো।")
                            .setPositiveButton("ঠিক আছে", null).show();
                    });
                }
            }).start();
        });
        box.addView(go);
        root.addView(box, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private String generateImage(String prompt) throws Exception {
        String base = prefs.getString("image_url", "").trim();
        String model = prefs.getString("image_model", "").trim();
        String key = prefs.getString("image_key", "").trim();
        if (base.isEmpty() || model.isEmpty() || key.isEmpty()) throw new Exception("Brain settings-এ Image API URL, model এবং key দাও।");
        String endpoint = apiUrl(base, "images/generations");
        HttpURLConnection c = (HttpURLConnection)new URL(endpoint).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(180000); c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + key);
        c.setRequestProperty("Content-Type", "application/json");
        JSONObject body = new JSONObject();
        body.put("model", model); body.put("prompt", prompt); body.put("n", 1); body.put("size", "1024x1024");
        OutputStream out = c.getOutputStream(); out.write(body.toString().getBytes("UTF-8")); out.close();
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String response = readAllSafe(in); c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + response);
        JSONObject data = new JSONObject(response).getJSONArray("data").getJSONObject(0);
        if (data.has("url") && !data.isNull("url")) return data.getString("url");
        if (data.has("b64_json") && !data.isNull("b64_json")) return "data:image/png;base64," + data.getString("b64_json");
        throw new Exception("Response-এ url বা b64_json পাওয়া যায়নি।");
    }

    private Bitmap loadImage(String source) throws Exception {
        Bitmap bmp;
        if (source.startsWith("data:image")) {
            String b64 = source.substring(source.indexOf(",") + 1);
            byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } else {
            HttpURLConnection c = (HttpURLConnection) new URL(source).openConnection();
            c.setConnectTimeout(15000); c.setReadTimeout(60000);
            bmp = BitmapFactory.decodeStream(c.getInputStream());
            c.disconnect();
        }
        if (bmp == null) throw new Exception("Image decode failed");
        return bmp;
    }

    private void showBitmap(Bitmap bmp) {
        ImageView image = new ImageView(this);
        image.setImageBitmap(bmp);
        image.setAdjustViewBounds(true);
        ScrollView sc = new ScrollView(this);
        sc.addView(image);
        new AlertDialog.Builder(this).setTitle("SUNT AI generated image")
            .setView(sc).setPositiveButton("বন্ধ", null).show();
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_FILE);
    }

    private void pickVideo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("video/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_VIDEO);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (request == PICK_VIDEO) {
            selectedVideoUri = uri;
            Toast.makeText(this, "ভিডিও সিলেক্ট হয়েছে।", Toast.LENGTH_SHORT).show();
            showVideo();
            return;
        }
        if (request == PICK_FILE) {
            try {
                String name = "selected file";
                android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                if (cursor != null) {
                    int idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx);
                    cursor.close();
                }
                String text = readLimited(getContentResolver().openInputStream(uri), 60000);
                selectedFileName = name;
                selectedFileText = "File: " + name + "\n" + text;
                new AlertDialog.Builder(this).setTitle("ফাইল যুক্ত হয়েছে")
                    .setMessage(name + " — " + text.length() + " characters. Chat-এ গিয়ে প্রশ্ন করো।")
                    .setPositiveButton("চ্যাটে যাও", (d,w) -> showChat())
                    .setNegativeButton("বন্ধ", null).show();
            } catch (Exception e) {
                new AlertDialog.Builder(this).setMessage("এই build-এ plain text/code/markdown/JSON ধরনের ফাইল পড়া যায়। PDF/DOCX-এর জন্য parser service প্রয়োজন।")
                    .setPositiveButton("ঠিক আছে", null).show();
            }
        }
    }

    private String readAllSafe(InputStream in) throws Exception {
        return in == null ? "" : readAll(in);
    }

    private String readLimited(InputStream in, int max) throws Exception {
        if (in == null) throw new Exception("ফাইল পড়া যায়নি");
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder b = new StringBuilder();
        char[] buf = new char[4096];
        int n;
        while (b.length() < max && (n = r.read(buf)) != -1) b.append(buf, 0, n);
        r.close();
        if (b.length() > max) b.setLength(max);
        int bad = 0;
        for (int i = 0; i < b.length(); i++) { char ch = b.charAt(i); if (ch == 0 || ch == 0xFFFD) bad++; }
        if (b.length() > 0 && bad * 50 > b.length()) throw new Exception("binary file");
        return b.toString();
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) throw new Exception("ফাইল/response stream পাওয়া যায়নি");
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder b = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) b.append(line).append('\n');
        r.close();
        return b.toString();
    }

    private void showVideo() {
        shell("Video workflow • FFmpeg / Whisper / Remotion worker-ready");
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(label("ভিডিও এডিটিং job-এর নির্দেশনা লিখো। v1.5 একটি backend job request পাঠাতে পারে; server-side worker-এ FFmpeg, Whisper, Remotion ও HyperFrames বসাতে হবে।"));
        EditText task = new EditText(this);
        task.setMinLines(4); task.setGravity(Gravity.TOP);
        task.setText(videoTask);
        task.setHint("যেমন: 30-সেকেন্ডের 3টি Shorts clip, Bangla subtitles, jump cuts...");
        box.addView(task);
        Button choose = new Button(this);
        choose.setText(selectedVideoUri == null ? "ভিডিও ফাইল বেছে নাও" : "ভিডিও সিলেক্ট হয়েছে — বদলাও");
        choose.setOnClickListener(v -> { videoTask = task.getText().toString(); pickVideo(); });
        box.addView(choose);
        EditText jobUrl = field("Video worker job API URL", prefs.getString("video_job_url", ""));
        EditText jobKey = field("Worker API key (optional)", prefs.getString("video_job_key", ""));
        jobKey.setInputType(129);
        box.addView(jobUrl); box.addView(jobKey);
        Button submit = new Button(this);
        submit.setText("Editing job পাঠাও");
        submit.setOnClickListener(v -> {
            videoTask = task.getText().toString();
            prefs.edit().putString("video_job_url", jobUrl.getText().toString().trim())
                .putString("video_job_key", jobKey.getText().toString().trim()).apply();
            if (selectedVideoUri == null) {
                Toast.makeText(this, "আগে ভিডিও ফাইল বেছে নাও।", Toast.LENGTH_SHORT).show(); return;
            }
            String endpoint = jobUrl.getText().toString().trim();
            if (endpoint.isEmpty()) {
                Toast.makeText(this, "Worker API URL সেট করো।", Toast.LENGTH_LONG).show(); return;
            }
            submit.setEnabled(false); submit.setText("Job পাঠানো হচ্ছে...");
            new Thread(() -> {
                try {
                    JSONObject payload = new JSONObject();
                    payload.put("task", task.getText().toString());
                    payload.put("video_uri", selectedVideoUri.toString());
                    payload.put("pipeline", new JSONArray().put("ffmpeg").put("whisper").put("remotion").put("hyperframes"));
                    payload.put("note", "The URI is a content URI on the Android device. Worker must implement authenticated upload or a content transfer flow; this request does not upload the video bytes.");
                    HttpURLConnection c = (HttpURLConnection)new URL(endpoint).openConnection();
                    c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(60000); c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json");
                    String k = jobKey.getText().toString().trim();
                    if (!k.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + k);
                    OutputStream out = c.getOutputStream(); out.write(payload.toString().getBytes("UTF-8")); out.close();
                    int code = c.getResponseCode();
                    InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                    String response = readAllSafe(in); c.disconnect();
                    if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + response);
                    runOnUiThread(() -> new AlertDialog.Builder(this).setTitle("Worker response").setMessage(response)
                        .setPositiveButton("ঠিক আছে", null).show());
                } catch (Exception e) {
                    String err = e.getMessage() == null ? "Worker error" : e.getMessage();
                    runOnUiThread(() -> new AlertDialog.Builder(this).setMessage("Job পাঠানো যায়নি: " + err)
                        .setPositiveButton("ঠিক আছে", null).show());
                } finally {
                    runOnUiThread(() -> { submit.setEnabled(true); submit.setText("Editing job পাঠাও"); });
                }
            }).start();
        });
        box.addView(submit);
        TextView limitation = label("সৎ সীমাবদ্ধতা: ফোনের content:// URI বাইরের server সরাসরি খুলতে পারবে না। এই সংস্করণ job metadata পাঠায়, ভিডিও bytes upload করে না। Production worker-এ secure upload endpoint, storage, FFmpeg/Whisper/Remotion pipeline, job status ও output download যোগ করতে হবে। yt-dlp কেবল নিজের/অনুমতিপ্রাপ্ত ভিডিওর জন্য। Claude Desktop Android-এর মধ্যে embed করা হয়নি।");
        limitation.setTextColor(0xFF9A3412);
        box.addView(limitation);
        ScrollView sc = new ScrollView(this); sc.addView(box);
        root.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

        private void showSkills() {
        shell("SUNT Skills • v1.7");
        ScrollView sc = new ScrollView(this);
        TextView t = label("ST-1 Brain (চিন্তার ইঞ্জিন):\n• Smart Thinking — প্রশ্ন বুঝে বিশ্লেষণ\n• Deep Reasoning — জটিল সমস্যা ধাপে ধাপে (Fast / Balanced / Deep)\n• Coding Brain — কোড লেখা ও bug খোঁজার নির্দেশনা\n• Task Planning — বড় কাজ ছোট ধাপে ভাগ\n• Self-check — উত্তর পাঠানোর আগে যাচাই\n• Dual Brain — Online → Local → Lite fallback\n\nST-2 Agent (v1.7):\n• Long-term Memory — Memory ট্যাবে দেখা/যোগ/মোছা; চ্যাটে \"মনে রাখো: ...\"\n• Tools — calculator, datetime, Wikipedia, ওয়েব পেজ পড়া (শুধু public সাইট)\n• Autonomous steps — প্রয়োজনে একাধিক tool ব্যবহার করে তারপর উত্তর\n• চ্যাট ইতিহাস অ্যাপ বন্ধ করলেও থাকে\n• Brain পরীক্ষা বাটন, rate-limit হলে auto retry\n\nযা এখনো নেই:\n• সত্যিকারের নিজস্ব trained model (ST-1 নিজে language model নয়)\n• Google-এর মতো সাধারণ web search (শুধু Wikipedia ও নির্দিষ্ট URL)\n• PDF/DOCX parsing, ভিডিও server worker\n\nSkills হলো system instruction; এটি model-কে train করে না।");
        sc.addView(t);
        root.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }
}
