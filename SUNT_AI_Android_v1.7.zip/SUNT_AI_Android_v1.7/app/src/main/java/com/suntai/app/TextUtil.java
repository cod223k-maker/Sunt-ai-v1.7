package com.suntai.app;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class TextUtil {
    private TextUtil() {}

    static String clip(String s, int max) {
        if (s == null) return "";
        s = s.trim();
        return s.length() <= max ? s : s.substring(0, max) + "\u2026";
    }

    /** Converts an HTML page to readable plain text (scripts/styles removed). */
    static String htmlToText(String html, int max) {
        if (html == null) return "";
        String t = html;
        t = t.replaceAll("(?is)<!--.*?-->", " ");
        t = t.replaceAll("(?is)<(script|style|noscript|svg|head)[^>]*>.*?</\\1>", " ");
        t = t.replaceAll("(?i)<br\\s*/?>|</(p|div|li|tr|h[1-6]|section|article)>", "\n");
        t = t.replaceAll("(?s)<[^>]*>", " ");
        t = decodeEntities(t);
        t = t.replaceAll("[ \\t\\u00a0]+", " ").replaceAll("\\s*\\n\\s*", "\n").replaceAll("\n{3,}", "\n\n").trim();
        return clip(t, max);
    }

    static String decodeEntities(String s) {
        Matcher m = Pattern.compile("&#(x?)([0-9a-fA-F]{1,6});").matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String rep = " ";
            try {
                int cp = Integer.parseInt(m.group(2), m.group(1).isEmpty() ? 10 : 16);
                if (cp > 0 && cp <= 0x10FFFF && !(cp >= 0xD800 && cp <= 0xDFFF)) rep = new String(Character.toChars(cp));
            } catch (NumberFormatException ignored) { }
            m.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        m.appendTail(sb);
        return sb.toString().replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
                .replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&");
    }
}
