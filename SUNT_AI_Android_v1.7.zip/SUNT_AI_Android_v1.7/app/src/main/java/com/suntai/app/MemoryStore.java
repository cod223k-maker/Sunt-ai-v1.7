package com.suntai.app;

import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * ST long-term memory. Facts are short notes the user asked to keep (or the agent saved with care); episodes are
 * digests of recent conversations. Everything is stored locally in SharedPreferences and can be edited by the user.
 */
final class MemoryStore {
    static final int MAX_FACTS = 200, MAX_FACT_LEN = 400, MAX_EPISODES = 8;
    private static final String K_FACTS = "st_facts_v2", K_EPI = "st_episodes_v2";
    private static final Object LOCK = new Object();

    private static final Pattern SECRET = Pattern.compile(
            "(?i)(api[ _-]?key|password|passwd|passcode|secret|token|otp|pin|\u09AA\u09BE\u09B8\u0993\u09DF\u09BE\u09B0\u09CD\u09A1)\\s*[:=]"
            + "|\\bsk-[a-z0-9_\\-]{12,}|\\bAIza[0-9A-Za-z_\\-]{20,}|\\bgh[pousr]_[A-Za-z0-9]{20,}"
            + "|\\b[A-Fa-f0-9]{32,}\\b|\\b[A-Za-z0-9+/_\\-]{40,}={0,2}");

    private static final Set<String> STOP = new HashSet<>(Arrays.asList(
            "the", "and", "is", "are", "was", "to", "of", "in", "on", "for", "my", "me", "you", "what", "who", "how",
            "ami", "amar", "tumi", "ki", "je", "\u098F\u09AC\u0982", "\u0986\u09AE\u09BE\u09B0", "\u0986\u09AE\u09BF", "\u0995\u09BF", "\u0995\u09C0"));

    static final class Fact {
        final long id;
        final String text;
        final long ts;
        final String src;
        Fact(long id, String text, long ts, String src) { this.id = id; this.text = text; this.ts = ts; this.src = src; }
    }

    private MemoryStore() {}

    static Kv kv(final SharedPreferences p) {
        return new Kv() {
            @Override public String get(String key, String def) { return p.getString(key, def); }
            @Override public void put(String key, String value) { p.edit().putString(key, value).apply(); }
            @Override public void remove(String key) { p.edit().remove(key).apply(); }
        };
    }

    // ---------- facts ----------

    static List<Fact> list(Kv kv) {
        synchronized (LOCK) { return load(kv); }
    }

    private static List<Fact> load(Kv kv) {
        List<Fact> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(kv.get(K_FACTS, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                String t = o.optString("t", "");
                if (t.isEmpty()) continue;
                out.add(new Fact(o.optLong("id", i), t, o.optLong("ts", 0), o.optString("s", "user")));
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static void save(Kv kv, List<Fact> all) {
        try {
            JSONArray a = new JSONArray();
            for (Fact f : all) {
                JSONObject o = new JSONObject();
                o.put("id", f.id);
                o.put("t", f.text);
                o.put("ts", f.ts);
                o.put("s", f.src);
                a.put(o);
            }
            kv.put(K_FACTS, a.toString());
        } catch (Exception ignored) { }
    }

    static Fact add(Kv kv, String text, String src) throws Exception {
        String t = text == null ? "" : text.replaceAll("\\s+", " ").trim();
        if (t.length() < 3) throw new Exception("\u09A4\u09A5\u09CD\u09AF\u099F\u09BF \u0996\u09C1\u09AC \u099B\u09CB\u099F");
        if (SECRET.matcher(t).find()) throw new Exception("\u09AA\u09BE\u09B8\u0993\u09DF\u09BE\u09B0\u09CD\u09A1/API key/\u0997\u09CB\u09AA\u09A8 \u0995\u09CB\u09A1 \u09AE\u09C7\u09AE\u09CB\u09B0\u09BF\u09A4\u09C7 \u09B0\u09BE\u0996\u09BE \u09B9\u09DF \u09A8\u09BE");
        if (t.length() > MAX_FACT_LEN) t = t.substring(0, MAX_FACT_LEN) + "\u2026";
        synchronized (LOCK) {
            List<Fact> all = load(kv);
            String norm = norm(t);
            for (Fact f : all) if (norm(f.text).equals(norm)) return f;
            long id = System.currentTimeMillis();
            for (Fact f : all) if (f.id >= id) id = f.id + 1;
            Fact nf = new Fact(id, t, System.currentTimeMillis(), "user".equals(src) ? "user" : "auto");
            all.add(nf);
            while (all.size() > MAX_FACTS) all.remove(0);
            save(kv, all);
            return nf;
        }
    }

    static boolean delete(Kv kv, long id) {
        synchronized (LOCK) {
            List<Fact> all = load(kv);
            boolean removed = false;
            for (int i = all.size() - 1; i >= 0; i--) if (all.get(i).id == id) { all.remove(i); removed = true; }
            if (removed) save(kv, all);
            return removed;
        }
    }

    static void clearAll(Kv kv) {
        synchronized (LOCK) {
            kv.remove(K_FACTS);
            kv.remove(K_EPI);
        }
    }

    private static String norm(String s) {
        return s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}\\p{M}]+", " ").trim();
    }

    private static Set<String> tokens(String s) {
        Set<String> out = new LinkedHashSet<>();
        if (s == null) return out;
        for (String w : norm(s).split(" ")) if (w.length() >= 2 && !STOP.contains(w)) out.add(w);
        return out;
    }

    private static final class Scored {
        final Fact f;
        final int score;
        Scored(Fact f, int score) { this.f = f; this.score = score; }
    }

    static List<Fact> search(Kv kv, String query, int k) {
        Set<String> q = tokens(query);
        List<Fact> res = new ArrayList<>();
        if (q.isEmpty()) return res;
        List<Scored> sc = new ArrayList<>();
        for (Fact f : list(kv)) {
            Set<String> ft = tokens(f.text);
            int s = 0;
            for (String w : q) {
                if (ft.contains(w)) { s += 2; continue; }
                if (w.length() >= 4) for (String x : ft) if (x.length() >= 4 && (x.startsWith(w) || w.startsWith(x))) { s += 1; break; }
            }
            if (s > 0) sc.add(new Scored(f, s));
        }
        Collections.sort(sc, new Comparator<Scored>() {
            @Override public int compare(Scored a, Scored b) {
                if (a.score != b.score) return b.score - a.score;
                return Long.compare(b.f.id, a.f.id);
            }
        });
        for (int i = 0; i < sc.size() && i < k; i++) res.add(sc.get(i).f);
        return res;
    }

    /** Facts relevant to the message plus the most recent ones, capped by size. */
    static String memoryBlock(Kv kv, String userMsg, int maxChars) {
        List<Fact> all = list(kv);
        if (all.isEmpty()) return "";
        LinkedHashSet<Long> seen = new LinkedHashSet<>();
        List<Fact> pick = new ArrayList<>();
        for (Fact f : search(kv, userMsg, 8)) if (seen.add(f.id)) pick.add(f);
        int recent = 0;
        for (int i = all.size() - 1; i >= 0 && recent < 5; i--) {
            Fact f = all.get(i);
            if (seen.add(f.id)) { pick.add(f); recent++; }
        }
        StringBuilder sb = new StringBuilder();
        for (Fact f : pick) {
            String line = "- " + f.text + "\n";
            if (sb.length() + line.length() > maxChars) break;
            sb.append(line);
        }
        return sb.toString();
    }

    // ---------- episodes (recent conversations) ----------

    static void addEpisode(Kv kv, String user, String assistant) {
        synchronized (LOCK) {
            try {
                JSONArray old = new JSONArray(kv.get(K_EPI, "[]"));
                JSONArray next = new JSONArray();
                for (int i = Math.max(0, old.length() - (MAX_EPISODES - 1)); i < old.length(); i++) next.put(old.getJSONObject(i));
                JSONObject o = new JSONObject();
                o.put("u", TextUtil.clip(user, 300));
                o.put("a", TextUtil.clip(assistant, 400));
                o.put("ts", System.currentTimeMillis());
                next.put(o);
                kv.put(K_EPI, next.toString());
            } catch (Exception ignored) { }
        }
    }

    static String episodesBlock(Kv kv) {
        StringBuilder sb = new StringBuilder();
        synchronized (LOCK) {
            try {
                JSONArray a = new JSONArray(kv.get(K_EPI, "[]"));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    sb.append("User: ").append(o.optString("u")).append("\nSUNT AI: ").append(o.optString("a")).append("\n");
                }
            } catch (Exception ignored) { }
        }
        return sb.toString();
    }

    // ---------- explicit "remember this" requests ----------

    private static final String[] TRIGGERS = {
            "mone rekho", "mone rakho", "mone rakhis", "mone rakhbe",
            "\u09AE\u09A8\u09C7 \u09B0\u09BE\u0996\u09CB", "\u09AE\u09A8\u09C7 \u09B0\u09C7\u0996\u09CB", "\u09AE\u09A8\u09C7 \u09B0\u09BE\u0996\u09AC\u09C7",
            "remember that", "remember this", "please remember", "remember:", "save this:", "note that"};

    /** Returns the fact to save if the message is an explicit "remember ..." request, otherwise null. */
    static String extractExplicit(String msg) {
        if (msg == null) return null;
        String m = msg.trim();
        if (m.isEmpty() || m.endsWith("?")) return null;
        String low = m.toLowerCase(Locale.ROOT);
        if (low.length() != m.length()) return null;
        for (String t : TRIGGERS) {
            int i = low.indexOf(t);
            if (i >= 0) {
                String fact = (m.substring(0, i) + " " + m.substring(i + t.length()))
                        .replaceAll("\\s+", " ")
                        .replaceAll("^[\\s,:;.\\-\u2013\u2014]+|[\\s,:;.\\-\u2013\u2014]+$", "").trim();
                return fact.length() >= 3 ? fact : null;
            }
        }
        return null;
    }
}
