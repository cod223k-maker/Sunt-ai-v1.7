package com.suntai.app;

/** Tiny key-value abstraction so the brain logic does not depend on Android classes. */
interface Kv {
    String get(String key, String def);
    void put(String key, String value);
    void remove(String key);
}
