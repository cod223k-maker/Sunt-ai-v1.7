package com.suntai.app;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Offline rule-based helper used only when no real model is reachable. It is NOT a trained AI. */
final class LiteBrain {
    private LiteBrain() {}

    static String reply(String prompt, String fileCtx, String reason) {
        String p = prompt == null ? "" : prompt.trim();
        String low = p.toLowerCase(Locale.ROOT);

        if (MemoryStore.extractExplicit(p) != null) return "\u09A0\u09BF\u0995 \u0986\u099B\u09C7\u0964";

        String math = tryMath(p);
        if (math != null) return "\uD83E\uDDEE " + math;

        if (low.length() < 40 && (low.matches(".*\\b(time|date)\\b.*") || low.contains("\u09B8\u09AE\u09DF") || low.contains("\u09A4\u09BE\u09B0\u09BF\u0996")))
            return new SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(new Date());

        if (low.contains("tomak k") || low.contains("tomake k") || low.contains("tumi ke") || low.contains("who are you")
                || low.contains("who made you") || low.contains("\u09A4\u09C1\u09AE\u09BF \u0995\u09C7") || low.contains("\u09A4\u09CB\u09AE\u09BE\u0995\u09C7 \u0995\u09C7"))
            return "\u0986\u09AE\u09BF SUNT AI \u2014 ST-1 Thinking Engine \u09A6\u09BF\u09DF\u09C7 \u099A\u09BE\u09B2\u09BF\u09A4\u0964 \u098F\u0996\u09A8 \u0995\u09CB\u09A8\u09CB AI model \u09B8\u0982\u09AF\u09C1\u0995\u09CD\u09A4 \u09A8\u09C7\u0987, \u09A4\u09BE\u0987 \u0986\u09AE\u09BF \u09B6\u09C1\u09A7\u09C1 Lite mode-\u098F (\u09B9\u09BF\u09B8\u09BE\u09AC, \u09B8\u09AE\u09DF, \u09AE\u09C7\u09AE\u09CB\u09B0\u09BF) \u0995\u09BE\u099C \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09BF\u0964 \u09AA\u09C1\u09B0\u09CB \u09B6\u0995\u09CD\u09A4\u09BF \u09AA\u09C7\u09A4\u09C7 Brain \u099F\u09CD\u09AF\u09BE\u09AC\u09C7 \u098F\u0995\u099F\u09BF model \u09AF\u09C1\u0995\u09CD\u09A4 \u0995\u09B0\u09CB\u0964";

        if (low.matches("^(hi|hello|hey|hlw|hlo|salam|assalamu alaikum)\\b.*") || low.contains("\u09B9\u09BE\u0987") || low.contains("\u09B9\u09CD\u09AF\u09BE\u09B2\u09CB"))
            return "\u09B9\u09CD\u09AF\u09BE\u09B2\u09CB! \u0986\u09AE\u09BF Lite mode-\u098F \u0986\u099B\u09BF\u0964 \u0997\u09AD\u09C0\u09B0 \u0989\u09A4\u09CD\u09A4\u09B0\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF Brain \u099F\u09CD\u09AF\u09BE\u09AC\u09C7 model \u09B8\u0982\u09AF\u09C1\u0995\u09CD\u09A4 \u0995\u09B0\u09CB\u0964";

        StringBuilder sb = new StringBuilder();
        sb.append("\u098F\u0996\u09A8 AI model \u09B8\u0982\u09AF\u09C1\u0995\u09CD\u09A4 \u09A8\u09C7\u0987, \u09A4\u09BE\u0987 \u0986\u09AE\u09BF \u098F\u0987 \u09AA\u09CD\u09B0\u09B6\u09CD\u09A8\u09C7\u09B0 \u0989\u09A4\u09CD\u09A4\u09B0 \u09A6\u09BF\u09A4\u09C7 \u09AA\u09BE\u09B0\u099B\u09BF \u09A8\u09BE\u0964\n");
        if (reason != null && !reason.trim().isEmpty()) sb.append("\u0995\u09BE\u09B0\u09A3: ").append(TextUtil.clip(reason.trim(), 220)).append("\n");
        sb.append("\n\u09A0\u09BF\u0995 \u0995\u09B0\u09A4\u09C7: Brain \u099F\u09CD\u09AF\u09BE\u09AC \u2192 Preset \u09AC\u09C7\u099B\u09C7 URL \u09A8\u09BE\u0993 \u2192 \u09A8\u09BF\u099C\u09C7\u09B0 API key \u0993 model ID \u09A6\u09BE\u0993 \u2192 \u201C\u09AA\u09B0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09B0\u09CB\u201D \u099A\u09BE\u09AA\u09CB \u2192 \u09B8\u09C7\u09AD\u0964");
        if (fileCtx != null && !fileCtx.isEmpty()) sb.append("\n(\u09AB\u09BE\u0987\u09B2\u09C7\u09B0 \u099F\u09C7\u0995\u09CD\u09B8\u099F \u09AF\u09C1\u0995\u09CD\u09A4 \u0986\u099B\u09C7, model \u09B8\u0982\u09AF\u09C1\u0995\u09CD\u09A4 \u09B9\u09B2\u09C7 \u09AC\u09BF\u09B6\u09CD\u09B2\u09C7\u09B7\u09A3 \u09B9\u09AC\u09C7\u0964)");
        sb.append("\n\u0985\u09AB\u09B2\u09BE\u0987\u09A8\u09C7\u0993 \u09AA\u09BE\u09B0\u09BF: \u09B9\u09BF\u09B8\u09BE\u09AC (\u09AF\u09C7\u09AE\u09A8 12*(3+4)), \u09B8\u09AE\u09DF/\u09A4\u09BE\u09B0\u09BF\u0996, \u0986\u09B0 \u201C\u09AE\u09A8\u09C7 \u09B0\u09BE\u0996\u09CB: ...\u201D \u09B8\u09C7\u09AD \u0995\u09B0\u09BE\u0964");
        return sb.toString();
    }

    static String tryMath(String p) {
        String s = p.replaceAll("(?i)^(calc|calculate|hisab|\u09B9\u09BF\u09B8\u09BE\u09AC)\\s*[:=]?\\s*", "").replaceAll("[=?]+$", "").trim();
        String n = Calculator.normalize(s);
        if (n.isEmpty() || !n.matches(".*[0-9].*") || !n.matches(".*[-+*/%^(].*")) return null;
        try {
            return s + " = " + Calculator.eval(s);
        } catch (Exception e) {
            return null;
        }
    }
}
