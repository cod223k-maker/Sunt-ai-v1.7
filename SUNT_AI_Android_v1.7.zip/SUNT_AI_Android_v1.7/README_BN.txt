SUNT AI v1.7 — ST-1 Brain + ST-2 Agent
=======================================

এই ভার্সনে কী নতুন
-------------------
ST-1 (চিন্তার ইঞ্জিন) — ST1Brain.java
  • Smart Thinking, Deep Reasoning, Coding Brain, Task Planning — model-কে কীভাবে ভাবতে হবে তার নির্দেশনা
  • চিন্তার মাত্রা: Fast / Balanced / Deep (Brain ট্যাবে)
  • Self-check: উত্তর পাঠানোর আগে আরেকবার যাচাই (ভুল পেলে সংশোধন)
  • Dual Brain: Online → Local → Lite (offline) fallback

ST-2 (Agent) — ST2Agent.java
  • Tools: calculator, datetime, wiki_search (Wikipedia), fetch_url (public ওয়েব পেজ), recall, remember
  • প্রয়োজনে একাধিক ধাপে tool চালিয়ে তারপর উত্তর (সর্বোচ্চ 4 / 7 ধাপ)
  • Long-term Memory: Memory ট্যাবে দেখা/যোগ/মোছা; চ্যাটে লিখো "মনে রাখো: ..."

অন্যান্য
  • Brain ট্যাবে "পরীক্ষা করো" বাটন + Gemini/Groq/OpenRouter preset URL
  • চ্যাট ইতিহাস অ্যাপ বন্ধ করলেও থাকে
  • 429/5xx হলে auto retry; আরও পরিষ্কার error বার্তা
  • Back বাটনে চ্যাটে ফেরা; ট্যাব বদলালে লেখা মুছে যায় না

কীভাবে চালু করবে
-----------------
1. এই ফোল্ডারের ভেতরের সব ফাইল (ফোল্ডার নিজে নয়) GitHub repo (Sunt-ai) এর root-এ আপলোড করো — পুরনো ফাইল replace হবে।
2. Actions → Build APK → Run workflow। শেষ হলে Artifacts থেকে APK নামাও।
3. অ্যাপে Brain ট্যাব → Preset বেছে URL নাও → নিজের API key ও model ID দাও → "Online Brain পরীক্ষা করো" → ✅ এলে "সেভ করো"।
   (model ছাড়া অ্যাপ শুধু Lite mode-এ থাকে: হিসাব, সময়, মেমোরি — এটি AI নয়।)

গুরুত্বপূর্ণ সত্য কথা
---------------------
• ST-1/ST-2 নিজে language model নয়। এটি তোমার দেওয়া model-কে ভালোভাবে ভাবতে, মনে রাখতে ও tool চালাতে সাহায্য করে। উত্তরের মান model-এর উপর নির্ভর করে।
• Free tier-এর limit ও model নাম provider বদলাতে পারে — provider-এর docs দেখো।
• Web search মানে Google নয়: শুধু Wikipedia ও নির্দিষ্ট URL পড়া যায়।
• fetch_url শুধু public সাইট পড়ে; localhost/LAN/private IP ব্লক করা (prompt-injection থেকে নিরাপত্তা)।
• ওয়েব থেকে পাওয়া তথ্য ব্যবহার করলে AI নিজে নিজে memory-তে কিছু সেভ করতে পারে না।
• Memory-তে পাসওয়ার্ড/API key সেভ হয় না। API key ফোনের সাধারণ storage-এ থাকে।
• Self-check ও Deep mode বেশি API call/token খরচ করে।

v1.6 এ যে বাগ/সমস্যা পাওয়া গিয়েছিল (v1.7-এ ঠিক করা)
----------------------------------------------------
1. v1.6 "Fixed"-এ ST-1 আদৌ যুক্ত ছিল না — ST1Brain.java ছিল শুধু আলাদা v1.5 source ফোল্ডারে। এখন একটাই প্রজেক্টে।
2. অ্যাপ বন্ধ করলে চ্যাট হারিয়ে যেত → এখন সেভ হয়।
3. Auto mode-এ Online ব্যর্থ হলে Local endpoint চেষ্টাই করত না → এখন করে।
4. কেন fallback হলো তা বলত না → এখন কারণ দেখায়।
5. HTTP error-এ provider-এর raw response দেখাত → এখন সংক্ষিপ্ত ও key মুছে দেখায়।
6. Rate limit (429) বা server error-এ retry ছিল না → এখন আছে।
7. কিছু model <think>…</think> লিখে ফেলত, কিছু model temperature নিত না → দুটোই সামলানো হয়েছে।
8. Back চাপলে সেটিংস থেকে অ্যাপ বন্ধ হয়ে যেত → এখন চ্যাটে ফেরে।
9. ট্যাব বদলালে লেখা মেসেজ মুছে যেত → এখন থাকে।
10. Memory শুধু শেষ ৮টি কথোপকথন, দেখা/মোছার উপায় ছিল না → এখন Memory ট্যাব।

এখনো যা নেই
-------------
• নিজস্ব trained model, PDF/DOCX parsing, ভিডিও server worker।
• Image generation-এর জন্য আলাদা Image API URL/model/key লাগে (Brain ট্যাবে ঘর আছে)।

Project
-------
Package: com.suntai.app • compileSdk 35 • targetSdk 34 • minSdk 23 • versionName 1.7
